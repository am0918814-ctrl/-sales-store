
-- ### engagement_data table

-- validate the datatype of columns
SELECT 
	COLUMN_NAME,
	DATA_TYPE
FROM
	INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'engagement_data'

-- Check for Duplicates
WITH temp AS(
	SELECT
		*,
		ROW_NUMBER() OVER(PARTITION BY ContentID, ContentType, EngagementDate, CampaignID, ProductID, ViewsClicksCombined ORDER BY (select null)) AS occurrence
	FROM engagement_data
)
SELECT *
FROM temp
WHERE occurrence <> 1

-- After Cleaning
SELECT
	EngagementID,
	CampaignID,
	ProductID,
	ContentID,
	CASE 
		WHEN ContentType IN ('socialmedia', 'SOCIALMEDIA', 'Socialmedia') THEN 'Social Media'
		WHEN ContentType IN ('BLOG', 'Blog', 'blog') THEN 'Blog'
		WHEN ContentType IN ('NEWSLETTER', 'newsletter', 'Newsletter') THEN 'Newsletter' 
		WHEN ContentType IN ('VIDEO', 'Video', 'video') THEN 'Video' 
	END AS ContentType,
	Likes,
	EngagementDate,
	CAST(LEFT(ViewsClicksCombined, CHARINDEX('-',ViewsClicksCombined)-1)AS INT) AS Views,
	CAST(RIGHT(ViewsClicksCombined, LEN(ViewsClicksCombined) - CHARINDEX('-',ViewsClicksCombined))AS INT) AS Clicks
FROM engagement_data

-- __________________________________________________________

-- ### customer_journey table

-- validate the datatype of columns
SELECT 
	COLUMN_NAME,
	DATA_TYPE
FROM
	INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'customer_journey'

-- After Cleaning
SELECT
	JourneyID,
	CustomerID,
	ProductID,
	VisitDate,
	LOWER(Stage) AS stage,
	Action,
	COALESCE(Duration, avg_stage_duration) AS duration
FROM (
	SELECT
		JourneyID,
		CustomerID,
		ProductID,
		VisitDate,
		Stage,
		Action,
		Duration,
        AVG(Duration) OVER (PARTITION BY LOWER(Stage)) AS avg_stage_duration
	FROM customer_journey
) AS subquery

-- ____________________________________________________

-- ### customer_reviews table

-- validate the datatype of columns
SELECT 
	COLUMN_NAME,
	DATA_TYPE
FROM
	INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'customer_reviews'

-- Check for Duplicates
WITH temp AS(
	SELECT
		*,
		ROW_NUMBER() OVER(PARTITION BY CustomerID, ProductID, ReviewDate, Rating ORDER BY ReviewDate) AS occurrence
	FROM customer_reviews
)
SELECT *
FROM temp
WHERE occurrence <> 1

-- After Cleaning
SELECT
	ReviewID,
	CustomerID,
	ProductID,
	ReviewDate,
	Rating,
	REPLACE(TRIM(ReviewText), '  ', ' ')
FROM customer_reviews

-- __________________________________________________________

-- ### fact_sales table

-- validate the datatype of columns
SELECT 
	COLUMN_NAME,
	DATA_TYPE
FROM
	INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'fact_sales'
-- Check for Duplicates
SELECT
	CustomerID,
	OrderID,
	Quantity,
	Revenue,
	COUNT(*)
FROM fact_sales
GROUP BY CustomerID, OrderID, Quantity, Revenue 
HAVING COUNT(*) > 1

-- After Cleaning
SELECT 
	OrderID,
	CustomerID,
	ProductID,
	CAST(UnitPrice AS DECIMAL(10,2)) AS UnitPrice,
	Quantity,
	CAST(Revenue AS DECIMAL(10,2)) AS Revenue,
	CAST(Cost AS DECIMAL(10,2)) AS Cost,
	CAST(Profit AS DECIMAL(10,2)) AS Profit
from fact_sales

-- __________________________________________________________
-- ### Customers table

-- validate the datatype of columns
SELECT 
	COLUMN_NAME,
	DATA_TYPE
FROM
	INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'customers'

-- After Cleaning
SELECT
	CustomerID,
	CustomerName,
	Gender,
	Age,
	Country,
	City
FROM customers
LEFT JOIN geography
ON geography.GeographyID = customers.GeographyID

-- __________________________________________________________

-- Create Cleaned version of the Tables

SELECT
	EngagementID,
	CampaignID,
	ProductID,
	ContentID,
	CASE 
		WHEN ContentType IN ('socialmedia', 'SOCIALMEDIA', 'Socialmedia') THEN 'Social Media'
		WHEN ContentType IN ('BLOG', 'Blog', 'blog') THEN 'Blog'
		WHEN ContentType IN ('NEWSLETTER', 'newsletter', 'Newsletter') THEN 'Newsletter' 
		WHEN ContentType IN ('VIDEO', 'Video', 'video') THEN 'Video' 
	END AS ContentType,
	Likes,
	EngagementDate,
	CAST(LEFT(ViewsClicksCombined, CHARINDEX('-',ViewsClicksCombined)-1)AS INT) AS Views,
	CAST(RIGHT(ViewsClicksCombined, LEN(ViewsClicksCombined) - CHARINDEX('-',ViewsClicksCombined))AS INT) AS Clicks
INTO engagement_data_clean
FROM engagement_data


SELECT
	JourneyID,
	CustomerID,
	ProductID,
	VisitDate,
	LOWER(Stage) AS stage,
	Action,
	COALESCE(Duration, avg_stage_duration) AS duration
INTO customer_journey_clean
FROM (
	SELECT
		JourneyID,
		CustomerID,
		ProductID,
		VisitDate,
		Stage,
		Action,
		Duration,
        AVG(Duration) OVER (PARTITION BY LOWER(Stage)) AS avg_stage_duration
	FROM customer_journey
) AS subquery


SELECT
	ReviewID,
	CustomerID,
	ProductID,
	ReviewDate,
	Rating,
	REPLACE(TRIM(ReviewText), '  ', ' ') AS ReviewText
INTO customer_reviews_clean
FROM customer_reviews


SELECT
	CAST(OrderID AS VARCHAR(20)) AS OrderID,
    CAST(CustomerID AS VARCHAR(20)) AS CustomerID,
    CAST(ProductID AS VARCHAR(20)) AS ProductID,
	OrderDate,
	UnitPrice,
	Quantity,
	Revenue,
	Cost,
	Profit
INTO fact_sales_clean
FROM fact_sales

SELECT
    CAST(ProductID AS VARCHAR(20)) AS ProductID,
	ProductName,
	Category,
	Price,
	cost
INTO products_clean
FROM products

SELECT
    CAST(CustomerID AS VARCHAR(20)) AS CustomerID,
	CustomerName,
	Gender,
	Age,
	CAST(GeographyID AS VARCHAR(20)) AS GeographyID
INTO customers_clean
FROM customers

SELECT
    CAST(geographyID AS VARCHAR(20)) AS GeographyID,
	Country,
	City
INTO geography_clean
FROM geography

-- ______________________

-- customer_journey_clean table Manipulation 
ALTER TABLE customer_journey_clean
ALTER COLUMN JourneyID VARCHAR(20)

ALTER TABLE customer_journey_clean
ALTER COLUMN CustomerID VARCHAR(20)

ALTER TABLE customer_journey_clean
ALTER COLUMN ProductID VARCHAR(20);

-- customer_reviews_clean table Manipulation 
ALTER TABLE customer_reviews_clean
ALTER COLUMN ReviewID VARCHAR(20)

ALTER TABLE customer_reviews_clean
ALTER COLUMN CustomerID VARCHAR(20)

ALTER TABLE customer_reviews_clean
ALTER COLUMN ProductID VARCHAR(20)

-- engagement_data_clean table Manipulation 
ALTER TABLE engagement_data_clean
ALTER COLUMN EngagementID VARCHAR(20)

ALTER TABLE engagement_data_clean
ALTER COLUMN ContentID VARCHAR(20)

ALTER TABLE engagement_data_clean
ALTER COLUMN CampaignID VARCHAR(20)

ALTER TABLE engagement_data_clean
ALTER COLUMN ProductID VARCHAR(20)

-- _____________________________________