﻿
-- Top 3 Products by average rating
SELECT TOP 3
	ProductName,
	avg_rating,
	count_of_reviews
FROM (
	select
		ProductName,
		CAST(AVG(CAST(rating AS DECIMAL(10,2))) as decimal(10,2)) as avg_rating,
		Count(rating)AS count_of_reviews
	from products
	INNER JOIN Customer_reviews_clean
	ON products.ProductID = Customer_reviews_clean.ProductID
	group by ProductName
) AS avg_rating_per_product
order by avg_rating DESC

---------------------------------------------------------------------------------
 -- Top 10 selling products by Quantity Sold

WITH TopSelling AS (
    SELECT 
        ProductID,
        SUM(Quantity) AS Total_quantity
    FROM Fact_Sales_clean
    GROUP BY ProductID
)
SELECT TOP 10
    ProductName,
    Total_quantity
FROM TopSelling
JOIN Products_clean
    ON Products_clean.ProductID = TopSelling.ProductID
GROUP BY 
    ProductName,
    Total_quantity
ORDER BY 
    Total_quantity DESC
 ---------------------------------------------------------------------------------------------
 
 -- Top 10 selling products by Profit
WITH TopProfit AS (
    SELECT 
        ProductID,
        SUM(Profit) AS TotalProfit
    FROM Fact_Sales_clean
    GROUP BY ProductID
)
SELECT TOP 10
    ProductName,
    TotalProfit
FROM TopProfit
JOIN Products 
    ON Products.ProductID = TopProfit.ProductID
GROUP BY 
    ProductName,
    TotalProfit
ORDER BY 
    TotalProfit DESC
---------------------------------------------------------------------------------------------

--TOP 5 CUSTOMERS by Number Of Purchases
SELECT TOP 5
    CustomerID,
    COUNT(DISTINCT OrderID) AS NumberOfPurchases,
    SUM(Revenue) AS TotalSpent
FROM Fact_Sales_clean
GROUP BY CustomerID
ORDER BY NumberOfPurchases DESC
 
---------------------------------------------------------------------------------------------

-- winner products (best-selling and most profitable items).
WITH SalesAgg AS (
    SELECT 
        ProductID,
        SUM(Quantity) AS TotalUnitsSold,
        SUM(Profit) AS TotalProfit
    FROM Fact_Sales_clean
    GROUP BY ProductID
)
SELECT 
    ProductName,
    TotalUnitsSold,
    TotalProfit,
    CASE 
        WHEN TotalUnitsSold = (SELECT MAX(TotalUnitsSold) FROM SalesAgg)
             AND TotalProfit = (SELECT MAX(TotalProfit) FROM SalesAgg)
            THEN 'Winner Product (Top Sales & Top Profit)'
        WHEN TotalUnitsSold = (SELECT MAX(TotalUnitsSold) FROM SalesAgg)
            THEN 'Most purchased product'
        WHEN TotalProfit = (SELECT MAX(TotalProfit) FROM SalesAgg)
            THEN 'Most Profitable Product'
        ELSE 'Regular Product'
    END AS ProductStatus
FROM SalesAgg
JOIN Products_clean
    ON Products_clean.ProductID = SalesAgg.ProductID
ORDER BY 
    TotalProfit DESC, 
    TotalUnitsSold DESC

--------------------------------------------------------------------------------------------------------------

-- Average time spent by customers who eventually Purchase
-- Average time spent by customers who eventually Drop-off
SELECT 
    'Purchase' AS Outcome,
    AVG(Total_Time) AS Avg_Time
FROM (
    SELECT 
        CustomerID,
        SUM(Duration) AS Total_Time
    FROM Customer_Journey_clean
    WHERE Action = 'Purchase'
    GROUP BY CustomerID
) AS t

UNION ALL

SELECT 
    'Drop-off' AS Outcome,
    AVG(Total_Time) AS Avg_Time
FROM (
    SELECT 
        CustomerID,
        SUM(Duration) AS Total_Time
    FROM Customer_Journey_clean
    WHERE Action = 'Drop-off'
    GROUP BY CustomerID
) AS t;

---------------------------------------------------------------------------------------------

--Top countries generating the highest sales?

SELECT 
    Country,
    SUM(Revenue) AS Total_Sales
FROM fact_sales_clean
JOIN customers_clean 
    ON customers_clean.CustomerID = fact_sales_clean.CustomerID
JOIN geography_clean 
    ON geography_clean.geographyID = customers_clean.geographyID
GROUP BY Country
ORDER BY Total_Sales DESC
---------------------------------------------------------------------------------------------
-- Total Profit by Age group
SELECT 
    CASE 
        WHEN Age BETWEEN 18 AND 25 THEN '18-25'
        WHEN Age BETWEEN 26 AND 35 THEN '26-35'
        WHEN Age BETWEEN 36 AND 45 THEN '36-45'
        WHEN Age BETWEEN 46 AND 60 THEN '46-60'
        ELSE '60+'
    END AS Age_Group,
    SUM(Profit) AS Total_Profit
FROM Fact_Sales_clean 
JOIN customers_clean
    ON customers_clean.CustomerID = Fact_Sales_clean.CustomerID
GROUP BY 
    CASE 
        WHEN Age BETWEEN 18 AND 25 THEN '18-25'
        WHEN Age BETWEEN 26 AND 35 THEN '26-35'
        WHEN Age BETWEEN 36 AND 45 THEN '36-45'
        WHEN Age BETWEEN 46 AND 60 THEN '46-60'
        ELSE '60+'
    END
ORDER BY Total_Profit DESC
---------------------------------------------------------------------------------------------
-- Gender distribution (male vs female) 

SELECT 
    Gender,
    COUNT(*) AS Total_Customers
FROM customers_clean
GROUP BY Gender
---------------------------------------------------------------------------------------------
 -- Total Revenue by Gender
SELECT 
    Gender,
    SUM(Revenue) AS Total_Revenue
FROM Fact_Sales_clean
JOIN customers_clean 
    ON customers_clean.CustomerID = Fact_Sales_clean.CustomerID
GROUP BY Gender
ORDER BY Total_Revenue DESC






